import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from scipy import interpolate
import joblib
from concurrent.futures import ThreadPoolExecutor
import tensorflow as tf
from sklearn.impute import SimpleImputer
import os

# 2. 数据预处理函数
def preprocess_data(df):
    # 处理2006-2016年数据的缺失情况
    # 1. 插值处理缺失值
    data_processed = df.drop(columns=['year', 'district', 'Y'])
    df_interpolated = data_processed.interpolate(method='linear', axis=0)
    print("插值后的 X 中缺失值：", np.isnan(df_interpolated).sum().sum())

    # 3. 使用SimpleImputer进行均值填充剩余的缺失值
    imputer = SimpleImputer(strategy='mean')  # 使用均值填充
    X_imputed = imputer.fit_transform(df_interpolated)

    # 确保填充后的数据没有缺失值
    print("填充后的 X 中缺失值：", np.isnan(X_imputed).sum().sum())

    # 4. 标准化特征X
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_imputed)

    return X_scaled


# Step 3: 加载模型函数
def load_model(model_path):
    """加载模型"""
    if model_path.endswith('.h5'):
        # 加载 TensorFlow Keras 模型
        return tf.keras.models.load_model(model_path)
    else:
        # 加载其他模型（如 joblib 保存的模型）
        return joblib.load(model_path)


# Step 4: 模型预测函数
def predict_with_models(models, data):
    """使用多个模型并行预测 y 值"""

    # 定义预测函数
    def predict(model):
        pred = model.predict(data)

        # 如果预测结果是多维数组且只有一个元素, 则转换为标量
        if pred.ndim == 1 and pred.size == 1:
            return pred.item()
        # 如果预测结果是二维数组且只有一行一列，则返回该单一元素
        elif pred.ndim == 2 and pred.shape[0] == 1 and pred.shape[1] == 1:
            return pred.item()
        else:
            # 对于多维数组，直接返回预测结果
            return pred

    # 使用 ThreadPoolExecutor 进行并行预测
    with ThreadPoolExecutor(max_workers=len(models)) as executor:
        predictions = list(executor.map(predict, models))

        # 将每个模型的预测结果合并（按列进行拼接）
        predictions_df = pd.DataFrame(predictions).T  # 转置，使每行代表一个样本的预测结果

        return predictions_df


# 假设模型文件路径已知
base_path = r"H:\NS_18\模型建立\模型汇总"

# 使用 os.path.join 拼接路径，确保路径正确
model_paths = [

    os.path.join(base_path, 'knn_model.joblib'),
    os.path.join(base_path, 'rf_model.joblib'),
    os.path.join(base_path, 'catboost_model.joblib'),
    os.path.join(base_path, 'lgb_model.joblib'),


]

# 加载所有模型
models = [load_model(path) for path in model_paths]

# Step 5: 处理文件夹中的所有Excel文件并进行预测
input_folder = r"G:\18X_00-22\18X汇总\各年汇总表格" # 这里填写你的文件夹路径
output_folder = r"G:\18X_00-22\18X汇总\各年汇总表格预测"
# 确保输出文件夹存在
os.makedirs(output_folder, exist_ok=True)

# 获取文件夹中的所有Excel文件
excel_files = [f for f in os.listdir(input_folder) if  f.endswith('.xlsx')]

for excel_file in excel_files:
    # 构建完整的文件路径
    file_path = os.path.join(input_folder, excel_file)
    df_all_sheets = pd.read_excel(file_path, sheet_name=None)  # 读取所有工作表

    predictions_all_sheets = {}

    for sheet_name, df in df_all_sheets.items():
        print(f"正在处理工作表: {sheet_name} 在文件: {excel_file}")

        # 保留'district'列，进行数据预处理
        X_scaled = preprocess_data(df)

        # 获取每个模型的预测结果
        print(f"开始对 {sheet_name} 使用每个模型进行预测...")
        predictions = predict_with_models(models, X_scaled)

        # 将'district'列添加到预测结果
        predictions['district'] = df['district']
        predictions['year'] = df['year']
        # 打印每个模型预测完成的提示
        for i, model_path in enumerate(model_paths):
            print(f"模型 {model_path} 对 {sheet_name} 的预测已完成。")

        # 将每个工作表的预测结果保存到字典
        predictions_all_sheets[sheet_name] = predictions

    # Step 6: 将预测结果写入新的 Excel 文件
    output_excel_path = os.path.join(output_folder, f'预测结果_{excel_file}')
    with pd.ExcelWriter(output_excel_path) as writer:
        for sheet_name, predictions in predictions_all_sheets.items():
            predictions.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"文件 {excel_file} 的预测结果已保存到 {output_excel_path}")

print("所有文件的预测结果处理完毕。")