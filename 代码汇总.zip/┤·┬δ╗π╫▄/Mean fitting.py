import matplotlib
# 设置后端
matplotlib.use('TkAgg')  # 或者 'Qt5Agg' 或 'Agg'
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# 从Excel文件读取数据
# 假设Excel文件包含一个名为 'Sheet1' 的工作表
df = pd.read_excel(r"H:\NS_18\模型建立\建立模型均值后对比分析.xlsx", sheet_name="Sheet1")

# 删除缺失值所在的行
df = df.dropna()

# 计算误差：实际值与预测值之差
df['Error'] = df['Y'] - df['YPRE']
df['Squared Error'] = df['Error'] ** 2

# 计算整体的误差评估指标
mse = mean_squared_error(df['Y'], df['YPRE'])
rmse = mean_squared_error(df['Y'], df['YPRE'], squared=False)
mae = mean_absolute_error(df['Y'], df['YPRE'])
r2 = r2_score(df['Y'], df['YPRE'])

# 输出误差评估结果
print(f"Mean Squared Error (MSE): {mse}")
print(f"Root Mean Squared Error (RMSE): {rmse}")
print(f"Mean Absolute Error (MAE): {mae}")
print(f"R-squared (R²): {r2}")

