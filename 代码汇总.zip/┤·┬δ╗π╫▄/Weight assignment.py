import pandas as pd

# 读取两个Excel文件
df1 = pd.read_excel(r"G:\18X_00-22\18X汇总\各年汇总表格预测\栅格值权重即校准系数.xlsx")
df2 = pd.read_excel(r"G:\18X_00-22\18X汇总\各年汇总表格预测\市级值汇总1.xlsx")

# 根据'distrci'列合并数据，添加后缀区分
merged_df = pd.merge(df1, df2, on='district', suffixes=('_1', '_2'))

# 创建结果DataFrame
result_df = merged_df[['district']].copy()

# 年份处理（2000-2016）
for year in range(2000, 2016):
    col1 = f"{year}_1"
    col2 = f"{year}_2"
    # 相乘得到新列
    result_df[year] = merged_df[col1] * merged_df[col2]

# 处理2017-2022年的数据
for year in range(2017, 2023):
    col1 = f"{year}_1"
    col2 = f"{year}_2"
    # 相乘得到新列
    result_df[year] = merged_df[col1] * merged_df[col2]

# 导出结果到Excel
result_df.to_excel(r"G:\18X_00-22\18X汇总\各年汇总表格预测\权重赋值.xlsx", index=False)

