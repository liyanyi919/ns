import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, Flatten, Dense, Dropout
import matplotlib.pyplot as plt
import matplotlib
# 设置后端
matplotlib.use('TkAgg')  # 或者 'Qt5Agg' 或 'Agg'# 1. 加载数据
from sklearn.inspection import permutation_importance
file_path = r"H:\NS_18\模型建立\1.xlsx"
df = pd.read_excel(file_path)
import shap
# 2. 数据预处理
for city in df['City'].unique():
    city_data = df[df['City'] == city].copy()
    city_data_years = city_data.loc[city_data['Year'].between(2006, 2016)].drop(columns=['City', 'Year'])

    if city_data_years.isnull().sum().sum() == city_data_years.size:
        df.loc[df['City'] == city, city_data_years.columns] = 0
    else:
        df.loc[df['City'] == city, city_data_years.columns] = city_data_years.interpolate(method='linear', axis=0)

df_interpolated = df.interpolate(method='linear', axis=0)
print("插值后的 X 中缺失值：", np.isnan(df_interpolated.drop(columns=['City', 'Year', 'Y'])).sum().sum())

# 3. 获取目标变量Y和特征X
X = df.drop(columns=['Y', 'City', 'Year']).values  # 特征X
y = df['Y'].values  # 目标变量Y

# 处理缺失值：使用SimpleImputer进行填充
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)
X = pd.DataFrame(X).fillna(0).values  # 填充缺失值
print("填充后的 X 中缺失值：", np.isnan(X_imputed).sum())

# 4. 标准化特征X
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 将X调整为CNN接受的格式 (样本数, 特征数, 1)
X_scaled = X_scaled[..., np.newaxis]  # 增加一个维度用于卷积操作

# 5. CNN模型架构
cnn_model = Sequential()
cnn_model.add(Conv1D(64, 3, activation='relu', input_shape=(X_scaled.shape[1], X_scaled.shape[2])))  # 1D卷积层
cnn_model.add(Dropout(0.2))
cnn_model.add(Conv1D(128, 3, activation='relu'))
cnn_model.add(Dropout(0.2))
cnn_model.add(Flatten())  # 展平层
cnn_model.add(Dense(64, activation='relu'))  # 全连接层
cnn_model.add(Dense(1))  # 输出层（回归任务）

# 6. 编译模型
cnn_model.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])

# 7. 交叉验证
kf = KFold(n_splits=10, shuffle=True, random_state=42)

mae_scores = []
mse_scores = []
r2_scores = []
rmse_scores = []
mape_scores = []

for train_index, test_index in kf.split(X_scaled):
    X_train, X_test = X_scaled[train_index], X_scaled[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # 训练CNN模型
    cnn_model.fit(X_train, y_train, epochs=50, batch_size=32, verbose=0)

    # 预测
    y_pred = cnn_model.predict(X_test)

    # 计算模型指标
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

    mae_scores.append(mae)
    mse_scores.append(mse)
    r2_scores.append(r2)
    rmse_scores.append(rmse)
    mape_scores.append(mape)


# 打印交叉验证后的平均得分
print(f"平均 MAE: {np.mean(mae_scores):.4f}")
print(f"平均 MSE: {np.mean(mse_scores):.4f}")
print(f"平均 R²: {np.mean(r2_scores):.4f}")
print(f"平均 RMSE: {np.mean(rmse_scores):.4f}")
print(f"平均 MAPE: {np.mean(mape_scores):.4f}")

# 8. 训练完整模型并对所有城市进行预测
cnn_model.fit(X_scaled, y, epochs=50, batch_size=32, verbose=0)

# 计算每个输入特征（X因子）与y之间的皮尔逊相关系数，作为特征重要性
correlations = []

y = y.flatten()  # 将 y 转换为一维数组

# 计算每个特征与y的相关性
for i in range(X_scaled.shape[1]):  # 假设X_scaled的列数是特征数量
    feature = X_scaled[:, i]  # 取第i个特征
    corr = np.corrcoef(feature.flatten(), y)[0, 1]  # 计算皮尔逊相关系数
    correlations.append(abs(corr))  # 使用绝对值作为特征重要性

# 将结果存储在pandas的Series中并按相关性降序排列
feature_importance = pd.Series(correlations, index=[f"特征{i+1}" for i in range(X_scaled.shape[1])])
feature_importance_sorted = feature_importance.sort_values(ascending=False)

# 打印出每个特征的重要性
print("各特征与目标变量y的重要性（按相关性排序）:")
print(feature_importance_sorted)

# 10. 保存预测结果到文件夹
output_folder = r"H:\NS_18\模型建立\补充模型算法数据\CNN"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 9. 保存训练好的模型
model_file_path = r"H:\NS_18\模型建立\补充模型算法数据\CNN\cnn_model.h5"
cnn_model.save(model_file_path)
print(f"模型已保存")

result_df = pd.DataFrame({
    'City': df['City'],
    'Year': df['Year'],
    'Actual Y': y,
    'Predicted Y': y_all_pred.flatten()
})

output_file_path = os.path.join(output_folder, '全局拟合结果.xlsx')
result_df.to_excel(output_file_path, index=False)
print(f"预测结果已保存至 {output_file_path}")

# 11. 可视化拟合结果
plt.figure(figsize=(10, 6))
plt.scatter(y, y_all_pred, color='blue', alpha=0.6, label="预测 vs 实际")
plt.plot([min(y), max(y)], [min(y), max(y)], color='red', linestyle='--', label="完美拟合")
plt.title("CNN 模型：实际值 vs 预测值")
plt.xlabel("实际值")
plt.ylabel("预测值")
plt.legend()
plt.grid(True)

# 保存图形
comparison_plot_path = os.path.join(output_folder, 'comparison_plot.png')
plt.savefig(comparison_plot_path)
print(f"比较图已保存至 {comparison_plot_path}")
plt.show()

# 12. 加载模型（如果需要）
# 加载保存的模型（例如，在未来的某个时间点）
loaded_model = tf.keras.models.load_model(model_file_path)
print("模型已加载")

# 使用加载的模型进行预测
y_loaded_pred = loaded_model.predict(X_scaled)