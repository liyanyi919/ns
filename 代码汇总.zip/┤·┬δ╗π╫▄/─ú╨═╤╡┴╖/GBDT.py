import pandas as pd
import numpy as np
import joblib
import os
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import lightgbm as lgb
from lightgbm import log_evaluation, early_stopping
import matplotlib
# 设置后端
matplotlib.use('TkAgg')  # 或者 'Qt5Agg' 或 'Agg'# 1. 加载数据
# 1. 加载数据
file_path = r"H:\NS_18\模型建立\1.xlsx"
df = pd.read_excel(file_path)

# 2. 数据预处理
# 假设'Year'为年份，'City'为城市，'Y'为目标变量
# 处理2006-2016年数据的缺失情况
for city in df['City'].unique():
    city_data = df[df['City'] == city].copy()

    # 获取06-16年的数据列
    city_data_years = city_data.loc[city_data['Year'].between(2006, 2016)].drop(columns=['City', 'Year'])

    # 判断06-16年是否全缺失
    if city_data_years.isnull().sum().sum() == city_data_years.size:
        # 如果全缺失，设置为0
        df.loc[df['City'] == city, city_data_years.columns] = 0
    else:
        # 否则使用插值法进行补充
        df.loc[df['City'] == city, city_data_years.columns] = city_data_years.interpolate(method='linear', axis=0)

df_interpolated = df.interpolate(method='linear', axis=0)
print("插值后的 X 中缺失值：", np.isnan(df_interpolated.drop(columns=['City', 'Year', 'Y'])).sum().sum())

# 3. 获取目标变量Y和特征X
X = df.drop(columns=['Y', 'City', 'Year']).values  # 特征X
y = df['Y'].values  # 目标变量Y

#  处理缺失值：使用SimpleImputer进行填充
imputer = SimpleImputer(strategy='mean')  # 使用均值填充
X_imputed = imputer.fit_transform(X)
# 强制填充所有 NaN 值
X = pd.DataFrame(X).fillna(0).values  # 或者使用均值填充 `fillna(X.mean())`
# 确保插值后没有缺失值
print("填充后的 X 中缺失值：", np.isnan(X_imputed).sum())

# 4. 标准化特征X
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 5. 交叉验证 (k折交叉验证)
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# 初始化模型：使用GradientBoostingRegressor
from sklearn.ensemble import GradientBoostingRegressor

gbdt_model = GradientBoostingRegressor(
    n_estimators=200,  # 弱学习器的数量
    learning_rate=0.05,  # 学习率
    max_depth=4,  # 树的最大深度
    random_state=42
)

# 交叉验证：计算模型在不同训练集和测试集上的表现
mae_scores = []
mse_scores = []
r2_scores = []
rmse_scores = []
mape_scores = []

for train_index, test_index in kf.split(X_scaled):
    X_train, X_test = X_scaled[train_index], X_scaled[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # 训练模型
    gbdt_model.fit(X_train, y_train)

    # 预测
    y_pred = gbdt_model.predict(X_test)

    # 计算模型指标
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

    mae_scores.append(mae)
    mse_scores.append(mse)
    r2_scores.append(r2)
    rmse_scores.append(rmse)
    mape_scores.append(mape)

# 打印交叉验证后的平均得分
print(f"平均 MAE: {np.mean(mae_scores):.4f}")
print(f"平均 MSE: {np.mean(mse_scores):.4f}")
print(f"平均 R²: {np.mean(r2_scores):.4f}")
print(f"平均 RMSE: {np.mean(rmse_scores):.4f}")
print(f"平均 MAPE: {np.mean(mape_scores):.4f}")

# 6. 训练完整模型并对所有城市进行预测
gbdt_model.fit(X_scaled, y)

# 查看特征重要性
importances = gbdt_model.feature_importances_
print(importances)

y_all_pred = gbdt_model.predict(X_scaled)

# 8. 保存预测结果到文件夹
output_folder = r"H:\NS_18\模型建立\GBDT"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 7. 保存训练好的模型
model_file_path = r"H:\NS_18\模型建立\GBDT\gbdt_model.joblib"
joblib.dump(gbdt_model, model_file_path)
print(f"模型已保存至 {model_file_path}")

evaluation_file_path = os.path.join(output_folder, 'evaluation_metrics.txt')
with open(evaluation_file_path, 'w', encoding='utf-8') as f:
    f.write(f"平均 MAE: {np.mean(mae_scores):.4f}\n")
    f.write(f"平均 MSE: {np.mean(mse_scores):.4f}\n")
    f.write(f"平均 R²: {np.mean(r2_scores):.4f}\n")
    f.write(f"平均 RMSE: {np.mean(rmse_scores):.4f}\n")
    f.write(f"平均 MAPE: {np.mean(mape_scores):.4f}\n")

print(f"评价结果已保存到: {evaluation_file_path}")
result_df = pd.DataFrame({
    'City': df['City'],
    'Year': df['Year'],
    'Actual Y': y,
    'Predicted Y': y_all_pred
})

output_file_path = os.path.join(output_folder, '全局拟合结果.xlsx')
result_df.to_excel(output_file_path, index=False)
print(f"预测结果已保存至 {output_file_path}")

# 9. 可视化拟合结果
plt.figure(figsize=(10, 6))
plt.scatter(y, y_all_pred, color='blue', alpha=0.6, label="预测 vs 实际")
plt.plot([min(y), max(y)], [min(y), max(y)], color='red', linestyle='--', label="完美拟合")
plt.title("GBDT 模型：实际值 vs 预测值")
plt.xlabel("实际值")
plt.ylabel("预测值")
plt.legend()
plt.grid(True)

# 保存图形
comparison_plot_path = os.path.join(output_folder, 'comparison_plot.png')
plt.savefig(comparison_plot_path)
print(f"比较图已保存至 {comparison_plot_path}")
plt.show()
plt.close()

# 10. 加载模型（如果需要）
# 加载保存的模型（例如，在未来的某个时间点）
loaded_model = joblib.load(model_file_path)
print("模型已加载")

# 使用加载的模型进行预测
y_loaded_pred = loaded_model.predict(X_scaled)