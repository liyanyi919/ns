import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

import os
import matplotlib.pyplot as plt
from tensorflow.keras import regularizers
import matplotlib
from sklearn.impute import SimpleImputer
# 设置后端
matplotlib.use('TkAgg')  # 或者 'Qt5Agg' 或 'Agg'
from tensorflow.keras.models import load_model
# 1. 加载数据
file_path = r"H:\NS_18\模型建立\1.xlsx"
df = pd.read_excel(file_path)

# 2. 数据预处理
for city in df['City'].unique():
    city_data = df[df['City'] == city].copy()

    # 获取06-16年的数据列
    city_data_years = city_data.loc[city_data['Year'].between(2006, 2016)].drop(columns=['City', 'Year'])

    # 判断06-16年是否全缺失
    if city_data_years.isnull().sum().sum() == city_data_years.size:
        df.loc[df['City'] == city, city_data_years.columns] = 0
    else:
        df.loc[df['City'] == city, city_data_years.columns] = city_data_years.interpolate(method='linear', axis=0)

# 3. 获取目标变量Y和特征X
X = df.drop(columns=['Y', 'City', 'Year']).values  # 特征X
y = df['Y'].values  # 目标变量Y

# 处理缺失值：使用SimpleImputer进行填充
imputer = SimpleImputer(strategy='mean')  # 使用均值填充
X_imputed = imputer.fit_transform(X)

# 强制填充所有 NaN 值
X = pd.DataFrame(X).fillna(0).values  # 或者使用均值填充 `fillna(X.mean())`
print("填充后的 X 中缺失值：", np.isnan(X_imputed).sum())

# 4. 标准化特征X
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 5. 交叉验证 (k折交叉验证)
kf = KFold(n_splits=10, shuffle=True, random_state=42)

# 初始化模型（使用TensorFlow构建一个简单的全连接神经网络）
def create_model():
    model = tf.keras.Sequential([
        tf.keras.layers.InputLayer(input_shape=(X_scaled.shape[1],)),
        tf.keras.layers.Dense(64, activation='relu',
                              kernel_regularizer=regularizers.l2(0.01)),  # L2正则化
        tf.keras.layers.Dropout(0.3),  # Dropout层，30%的神经元会被丢弃
        tf.keras.layers.Dense(32, activation='relu',
                              kernel_regularizer=regularizers.l2(0.01)),  # L2正则化
        tf.keras.layers.Dropout(0.3),  # Dropout层
        tf.keras.layers.Dense(1)  # 回归问题输出层
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

mae_scores = []
mse_scores = []
r2_scores = []
rmse_scores = []
mape_scores = []

# 交叉验证：计算模型在不同训练集和测试集上的表现
for train_index, test_index in kf.split(X_scaled):
    X_train, X_test = X_scaled[train_index], X_scaled[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # 创建并训练模型，加入EarlyStopping防止过拟合
    model = create_model()
    early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    model.fit(X_train, y_train, epochs=100, batch_size=32, validation_split=0.2, callbacks=[early_stopping], verbose=0)

    # 预测
    y_pred = model.predict(X_test).flatten()

    # 计算模型指标
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mse)
    mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100

    mae_scores.append(mae)
    mse_scores.append(mse)
    r2_scores.append(r2)
    rmse_scores.append(rmse)
    mape_scores.append(mape)

# 打印交叉验证后的平均得分
print(f"平均 MAE: {np.mean(mae_scores):.4f}")
print(f"平均 MSE: {np.mean(mse_scores):.4f}")
print(f"平均 R²: {np.mean(r2_scores):.4f}")
print(f"平均 RMSE: {np.mean(rmse_scores):.4f}")
print(f"平均 MAPE: {np.mean(mape_scores):.4f}")

# 6. 训练完整模型并对所有城市进行预测
final_model = create_model()
final_model.fit(X_scaled, y, epochs=100, batch_size=32, validation_split=0.2, callbacks=[early_stopping], verbose=0)

# 对所有城市进行预测
y_all_pred = final_model.predict(X_scaled).flatten()

# 查看模型的层次结构，确认层的顺序
final_model.summary()

# 确保你访问的是正确的层
# 第一个 Dense 层通常是 layers[0]，因为 InputLayer 不会有可训练的权重
first_layer_weights = final_model.layers[0].get_weights()[0]  # 获取第一个 Dense 层的权重矩阵

# 获取特征和神经元名称
feature_names = [f"Feature_{i+1}" for i in range(X_scaled.shape[1])]  # 假设X_scaled有35个特征
neuron_names = [f"Neuron_{i+1}" for i in range(first_layer_weights.shape[1])]  # 第一层有64个神经元

# 将权重矩阵转化为DataFrame，以便更易读
weights_df = pd.DataFrame(first_layer_weights, columns=neuron_names, index=feature_names)

# 打印权重矩阵
print("\n第一层权重矩阵（特征对神经元的影响）：")
print(weights_df)

# 计算每个特征对模型输出的总贡献（按绝对值求和）
feature_contributions = weights_df.abs().sum(axis=1).sort_values(ascending=False)

# 打印特征贡献排序
print("\n按影响力排序的特征：")
print(feature_contributions)

# 8. 保存预测结果到文件夹
output_folder = r"H:\NS_18\模型建立\补充模型算法数据\TensorFlow"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 7. 保存训练好的模型
final_model.save(r"H:\NS_18\模型建立\补充模型算法数据\TensorFlow\TensorFlow_model.h5")
print(f"模型已保存")


result_df = pd.DataFrame({
    'City': df['City'],
    'Year': df['Year'],
    'Actual Y': y,
    'Predicted Y': y_all_pred
})

output_file_path = os.path.join(output_folder, '全局拟合结果.xlsx')
result_df.to_excel(output_file_path, index=False)
print(f"预测结果已保存至 {output_file_path}")

# 9. 可视化拟合结果
plt.figure(figsize=(10, 6))
plt.scatter(y, y_all_pred, color='blue', alpha=0.6, label="预测 vs 实际")
plt.plot([min(y), max(y)], [min(y), max(y)], color='red', linestyle='--', label="完美拟合")
plt.title("TensorFlow 模型：实际值 vs 预测值")
plt.xlabel("实际值")
plt.ylabel("预测值")
plt.legend()
plt.grid(True)

# 保存图形
comparison_plot_path = os.path.join(output_folder, 'comparison_plot.png')
plt.savefig(comparison_plot_path)
print(f"比较图已保存至 {comparison_plot_path}")
plt.show()

# 10. 加载模型（如果需要）
# 加载保存的模型（例如，在未来的某个时间点）
model = load_model(model_path)

# 使用加载的模型进行预测
y_loaded_pred = loaded_model.predict(X_scaled).flatten()
