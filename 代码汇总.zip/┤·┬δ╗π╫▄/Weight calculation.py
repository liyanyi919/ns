import pandas as pd


def calculate_weights(input_file, output_file):
    # 读取输入的 Excel 文件
    sheet = pd.read_excel(input_file)

    # 获取所有年份列（假设列名是 2006, 2007, 2008 ）
    years = [2000, 2001, 2002, 2003, 2004, 2005,2006，2007，2008，2009，2010，2012，2013，2014，2015，2016， 2017, 2018, 2019, 2020, 2021,2022]

    # 初始化一个空的 DataFrame 用来保存权重计算结果
    weight_result = []

    # 遍历所有年份列进行计算
    for year in years:
        # 提取 'city' 和年份对应的数据
        year_data = sheet[['city', year]].copy()

        # 计算同一个 city 和年份下所有值的总和
        city_year_sum = year_data.groupby('city')[year].transform('sum')

        # 计算权重：当前年份值 / 同一城市该年份值的总和
        year_data['weight'] = year_data[year] / city_year_sum

        # 只保留 city 和计算出的 weight 列
        weight_result.append(year_data[['city', 'weight']].rename(columns={'weight': f'weight_{year}'}))

    # 合并所有年份的权重结果
    final_result = pd.concat(weight_result, axis=1)

    # 去除重复的 'city' 列
    final_result = final_result.loc[:, ~final_result.columns.duplicated()]

    # 将结果保存到新的 Excel 文件
    with pd.ExcelWriter(output_file) as writer:
        final_result.to_excel(writer, sheet_name='City_Weights', index=False)


# 调用函数，计算权重并保存到新文件
input_file = r"G:\18X_00-22\18X汇总\各年汇总表格预测\栅格值汇总.xlsx" # 输入文件路径
output_file = r"G:\18X_00-22\18X汇总\各年汇总表格预测\栅格值权重即校准系数.xlsx"  # 输出文件路径
calculate_weights(input_file, output_file)
